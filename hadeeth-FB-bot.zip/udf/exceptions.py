class IncorrectEmail(Exception): pass
class IncorrectPassword(Exception): pass
class UsernameDoesNotExist(Exception): pass
