#this empty module is used as a bridge to share global vars between other modules (ie: g.var)
# import os; global cwd; cwd = os.getcwd()