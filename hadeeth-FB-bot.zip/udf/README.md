**This Repo is not for you to use.** _as I am not going to document or maintain it_ <br>
I may do that later <br>
,but now, you can figure how to use it yourself [if you want].<br>
<hr>

**Q: Then, Why You Shared it as a public Repo ??**<br>
A: it is only for you to download it as a dependency for my other Repos<br>
like this one: https://github.com/ibrahemesam/DirShare

